//
//  TableViewController.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 21/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit
class TableViewController: UITableViewController {

    @IBOutlet var tabView: UITableView!
    var memes: [MemeModel]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }

    override func viewWillAppear(_ animated: Bool) {
      super.viewWillAppear(true)
        tableView.reloadData()
   
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return memes.count
    }
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier:"TableViewCell")as! TableViewCell
        let meme = memes[indexPath.row]
        cell.memeImage.image = meme.memeimage
        cell.memeLabel.text = "\(String(describing: meme.toptextfield!))\(String(describing: meme.buttomtextfield!))"
           return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let memeView = self.storyboard?.instantiateViewController(withIdentifier: "InfoMemeViewController") as! InfoMemeViewController
        memeView.meme = self.memes[indexPath.row]
        self.navigationController?.pushViewController(memeView, animated: true)
        
    }
    
    
}


