//
//  InformatiomMemeViweController.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 21/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class InformatiomMemeViweController: UIViewController {
   
    
    @IBOutlet weak var editButton: UIBarButtonItem!
    @IBOutlet weak var imageViwe: UIImageView!
    
    var meme : Meme!
    override func viewDidLoad() {
        self.viewDidLoad()
        
        imageViwe.image = meme.memeimage
    }
    
    @IBAction func editAction(_ sender: Any) {
        let VCmemeV1 = storyboard!.instantiateViewController(withIdentifier: "VCmemeV1") as! VCmemeV1
     VCmemeV1.memeInfo = self.meme
        self.navigationController?.pushViewController(VCmemeV1, animated: true)
    }
    
    
    
}
