//
//  CollectionViweController.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 21/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class CollectionViweController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
 
    var memes: [MemeModel]! {
        let object = UIApplication.shared.delegate
        let appDelegate = object as! AppDelegate
        return appDelegate.memes
    }
    
    @IBOutlet var collView: UICollectionView!
    @IBOutlet var collectionLayout: UICollectionViewFlowLayout!
    
    override func viewWillAppear(_ animated: Bool) {
     super.viewWillAppear(true)
       collView.reloadData()
       collView.allowsMultipleSelection = true
    
        let space:CGFloat = 3.0
        let dimension = (view.frame.size.width - (2 * space)) / 3.0
        
        collectionLayout.minimumInteritemSpacing = space
        collectionLayout.minimumLineSpacing = space
        collectionLayout.itemSize = CGSize(width: dimension, height: dimension)
       
        
    }
    

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
          return memes.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        cell.memeImage.image = memes[indexPath.row].memeimage
        return cell
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let memeView = self.storyboard!.instantiateViewController(withIdentifier: "InfoMemeViewController") as! InfoMemeViewController
        memeView.meme = self.memes[indexPath.item]
        self.navigationController!.pushViewController(memeView, animated: true)
    }
    
    
    
    
    
}

