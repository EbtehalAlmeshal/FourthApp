//
//  VCmemeV1.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 21/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//
//
//  VCmemeV1.swift
//  P2.1
//
//  Created by ابتهال عبدالعزيز on 10/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class VCmemeV1: UIViewController , UIImagePickerControllerDelegate,
UINavigationControllerDelegate , UITextFieldDelegate {
    
    @IBOutlet weak var albumButton: UIBarButtonItem!
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var imageviwe: UIImageView!
    @IBOutlet weak var topBar: UIToolbar!
    @IBOutlet weak var topTextField: UITextField!
    @IBOutlet weak var buttomTextField: UITextField!
    @IBOutlet weak var buttonBar: UIToolbar!
    @IBOutlet weak var shareButton: UIBarButtonItem!
    
    var memeInfo : MemeModel?
    
    
    
    let memeTextAttributes:[NSAttributedString.Key :Any] = [
        NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeColor.rawValue): UIColor.black,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.foregroundColor.rawValue): UIColor.white,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.font.rawValue): UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
        NSAttributedString.Key(rawValue: NSAttributedString.Key.strokeWidth.rawValue): -0.4]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttomTextField.delegate = self
        
        
        func stylizeTextField(textField: UITextField) {
            textField.defaultTextAttributes = memeTextAttributes
            
            topTextField.text = "Top"
            buttomTextField.text = "Bottom"
            textField.textAlignment = .center
            textField.delegate = self
        }
        stylizeTextField(textField: topTextField)
        stylizeTextField(textField: buttomTextField)
    }
    override func viewWillAppear(_ animated:Bool) {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
        
        if let memeInfo = memeInfo as MemeModel! {
            imageviwe.image = memeInfo.memeimage
        }
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    @objc  func keyboardWillShow( _ notification :  Notification) {
        view.frame.origin.y = 0
        if (buttomTextField.isFirstResponder){
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
    }
    @objc  func subscribeToKeyboardNotifications() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(VCmemeV1.keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(VCmemeV1.keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    @objc func keyboardWillHide(_ notification:Notification) {
        if (buttomTextField.isFirstResponder){
            view.frame.origin.y = 0
        }
    }
    @objc func unsubscribeFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue: "keyboardWillShow"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name(rawValue:"keyboardWillHide:" ), object: nil)
        
    }
    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        
        let userInfo =  notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if topTextField.text == "Top" || buttomTextField.text == "Bottom"{
            textField.text = " "}
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func pickAnImageFromSource(source: UIImagePickerController.SourceType) {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = source
        present(pickerController, animated: true, completion: nil)
    }
    
    @IBAction func cameraButtonAction(_ sender: Any) {
        pickAnImageFromSource(source: .camera)
    }
    @IBAction func photoLibraryAction(_ sender: Any) {
        pickAnImageFromSource(source: .photoLibrary)
    }
    // add photo to imeage viwe :) finally i do it :)))
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let imagePicker = info[UIImagePickerController.InfoKey.originalImage]as?UIImage{
            imageviwe.image = imagePicker
            shareButton.isEnabled = true
        }
        self.dismiss(animated: true, completion: nil)
        
    }
    
    func dismissView() {
        dismiss(animated: true, completion: nil)
    }
  
   func save (){
    let memeimage = generateMemedImage()
        let Meme = MemeModel(toptextfield: topTextField.text!, buttomtextfield: buttomTextField.text!, originalImage: imageviwe.image, memeimage:memeimage)
       
       // Add it to the memes array in the Application Delegate
    
            let object = UIApplication.shared.delegate
            let appDelegate = object as! AppDelegate
             appDelegate.memes.append(Meme)
        

        UIImageWriteToSavedPhotosAlbum(memeimage, nil, nil, nil)
       dismiss(animated: true, completion: nil)
  
    
    }
    // Share
    @IBAction func sharePhoto (){
        let image = UIImage()
        let controller = UIActivityViewController(activityItems: [image], applicationActivities:nil)
        controller.completionWithItemsHandler = {
            (activity:UIActivity.ActivityType?, completed:Bool, returneditems:[Any]?, error:Error?)in
            if (completed){
                self.save()
            }}
        present(controller, animated: true, completion: nil)
        
    }
    // cancel buttom
    @IBAction func cancelButtonAction(_ sender: Any) {
        
        dismissView()
        return
        
        topTextField.text = "Top"
        buttomTextField.text = "Bottom"
        self.imageviwe.image = nil
        
        
    }
    func generateMemedImage() -> UIImage {
        
        // TODO: Hide toolbar and navbar
        topBar.isHidden = true
        buttonBar.isHidden = true
        
        // Render view to an image
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let image:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        // TODO: Show toolbar and navbar
        topBar.isHidden = false
        buttonBar.isHidden = false
        
        return image
    }
    
    
    
    
    
}


