//
//  Meme.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 21/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//
import UIKit
struct MemeModel {
    let toptextfield: String!
    let buttomtextfield: String!
    let originalImage : UIImage!
    let memeimage : UIImage!
    
    
    
}
