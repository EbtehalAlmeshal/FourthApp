//
//   InfoMemeViewController.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 22/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit
class  InfoMemeViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var editButton: UIBarButtonItem!
    
    
    var meme : MemeModel!
    override func viewDidLoad() {
       super.viewDidLoad()
        
        imageView.image = meme.memeimage
    }
    
    @IBAction func editAction(_ sender: Any) {
        let VCmemeV1 = storyboard!.instantiateViewController(withIdentifier: "VCmemeV1") as! VCmemeV1
        VCmemeV1.memeInfo = self.meme
        self.navigationController?.pushViewController(VCmemeV1, animated: true)
    }
    
    
    
}
