//
//  CollectionViweCell.swift
//  P2.2
//
//  Created by ابتهال عبدالعزيز on 24/02/1440 AH.
//  Copyright © 1440 ابتهال عبدالعزيز. All rights reserved.
//

import UIKit

class CollectionViewCell : UICollectionViewCell{
    
      @IBOutlet weak var memeImage: UIImageView!
    
}
